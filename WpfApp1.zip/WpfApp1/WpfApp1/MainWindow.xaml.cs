﻿using System;
using System.Net.Http;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private HttpClient client = new HttpClient();

        public MainWindow()
        {
            InitializeComponent();
            RecvLoop();
        }

        private async void RecvLoop()
        {
            while (true)
            {
                try
                {
                    string response = await client.GetStringAsync("https://simplechatapi20240217143733.azurewebsites.net/api/Function1");

                    ChatBox.Text += response + "\n\n";
                }
                catch (Exception er){}
            }
        }

        private async void TxtBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !string.IsNullOrWhiteSpace(TxtBox1.Text))
            {
                ChatBox.Text += "You: ";
                var content = new StringContent(JsonConvert.SerializeObject(new { Text = TxtBox1.Text }));
                var resp = await client.PostAsync("https://simplechatapi20240217143733.azurewebsites.net/api/Function1", content);
                string response = await resp.Content.ReadAsStringAsync();
                TxtBox1.Text = "";

            }
        }
    }
}
